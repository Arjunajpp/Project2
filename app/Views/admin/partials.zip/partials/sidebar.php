<div class="col-md-3">
    <div class="list-group">
        <!-- Link menuju Dashboard -->
        <a href="<?= base_url('admin/dashboard') ?>" class="list-group-item list-group-item-action">
            <i class="fas fa-home"></i> Dashboard
        </a>

        <!-- Link menuju Data Aset -->
        <a href="<?= base_url('admin/dataaset') ?>" class="list-group-item list-group-item-action">
            <i class="fas fa-boxes"></i> Data Aset
        </a>

        <!-- Link untuk Superadmin -->
        <?php if (session()->get('role') == 'superadmin'): ?>
        
        <!-- Dropdown untuk Kategori -->
        <a href="#dependencyMenu" class="list-group-item list-group-item-action" data-toggle="collapse" aria-expanded="false" aria-controls="dependencyMenu">
            <i class="fas fa-box"></i> Kategori <i class="fas fa-caret-down"></i>
        </a>

        <div id="dependencyMenu" class="collapse">
            <!-- Kategori Aset -->
            <a href="<?= base_url('admin/kategori-aset') ?>" class="list-group-item list-group-item-action ml-3">
                <i class="fas fa-box"></i> Aset
            </a>

            <!-- Kategori Data -->
            <a href="<?= base_url('admin/kategori-data') ?>" class="list-group-item list-group-item-action ml-3">
                <i class="fas fa-database"></i> Data
            </a>

            <!-- Anggaran -->
            <a href="<?= base_url('admin/anggaran') ?>" class="list-group-item list-group-item-action ml-3">
                <i class="fas fa-wallet"></i> Anggaran
            </a>

            <!-- Ruangan -->
            <a href="<?= base_url('admin/ruangan') ?>" class="list-group-item list-group-item-action ml-3">
                <i class="fas fa-door-open"></i> Ruangan
            </a>
        </div>

        <!-- Manage Users -->
        <a href="<?= base_url('admin/schools') ?>" class="list-group-item list-group-item-action">
            <i class="fas fa-users"></i> Manage Users
        </a>

        <!-- Persetujuan Aset -->
        <a href="<?= base_url('admin/approval') ?>" class="list-group-item list-group-item-action">
            <i class="fas fa-check-circle"></i> Persetujuan Aset
        </a>

        <?php endif; ?>
    </div>
</div>
