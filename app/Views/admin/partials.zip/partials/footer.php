<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<!-- Chart.js for displaying dynamic charts -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<!-- jQuery and Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

<!-- Script for Chart.js -->
<script>
    document.addEventListener("DOMContentLoaded", function() {
        var ctx = document.getElementById('dataChart').getContext('2d');
        var dataChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Data Umum', 'Data RKB', 'Data Fisik Prioritas'],
                datasets: [{
                    label: 'Jumlah Data',
                    data: [<?= $totalDataUmum ?? 0 ?>, <?= $totalDataRKB ?? 0 ?>, <?= $totalDataFisikPrioritas ?? 0 ?>],
                    backgroundColor: ['#007bff', '#28a745', '#dc3545'],
                    borderColor: ['#0056b3', '#1e7e34', '#c82333'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });
</script>
</body>
</html>
